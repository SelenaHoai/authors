import './App.css';
import Main from './views/Main'
// import Form from './views/Form'


function App() {
  return (
    <div className="App">
      <h1 style={{marginLeft:30, marginTop:20}}> Favorite Authors </h1>
      <Main/>

    </div>
  );
}

export default App;
